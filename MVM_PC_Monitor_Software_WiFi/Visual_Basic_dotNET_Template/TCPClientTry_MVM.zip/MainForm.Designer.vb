﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.LabelMain = New System.Windows.Forms.Label()
        Me.ButtonConnect = New System.Windows.Forms.Button()
        Me.ButtonClose = New System.Windows.Forms.Button()
        Me.ButtonSend = New System.Windows.Forms.Button()
        Me.ButtonReceive = New System.Windows.Forms.Button()
        Me.TimerMain = New System.Windows.Forms.Timer(Me.components)
        Me.ButtonStart = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'LabelMain
        '
        Me.LabelMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelMain.Location = New System.Drawing.Point(12, 308)
        Me.LabelMain.Name = "LabelMain"
        Me.LabelMain.Size = New System.Drawing.Size(280, 33)
        Me.LabelMain.TabIndex = 0
        '
        'ButtonConnect
        '
        Me.ButtonConnect.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonConnect.Location = New System.Drawing.Point(3, 12)
        Me.ButtonConnect.Name = "ButtonConnect"
        Me.ButtonConnect.Size = New System.Drawing.Size(86, 46)
        Me.ButtonConnect.TabIndex = 1
        Me.ButtonConnect.Text = "Connect"
        Me.ButtonConnect.UseVisualStyleBackColor = True
        '
        'ButtonClose
        '
        Me.ButtonClose.Enabled = False
        Me.ButtonClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonClose.Location = New System.Drawing.Point(3, 115)
        Me.ButtonClose.Name = "ButtonClose"
        Me.ButtonClose.Size = New System.Drawing.Size(86, 44)
        Me.ButtonClose.TabIndex = 2
        Me.ButtonClose.Text = "Close"
        Me.ButtonClose.UseVisualStyleBackColor = True
        '
        'ButtonSend
        '
        Me.ButtonSend.Enabled = False
        Me.ButtonSend.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSend.Location = New System.Drawing.Point(3, 165)
        Me.ButtonSend.Name = "ButtonSend"
        Me.ButtonSend.Size = New System.Drawing.Size(86, 45)
        Me.ButtonSend.TabIndex = 3
        Me.ButtonSend.Text = "Send"
        Me.ButtonSend.UseVisualStyleBackColor = True
        '
        'ButtonReceive
        '
        Me.ButtonReceive.Enabled = False
        Me.ButtonReceive.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonReceive.Location = New System.Drawing.Point(3, 216)
        Me.ButtonReceive.Name = "ButtonReceive"
        Me.ButtonReceive.Size = New System.Drawing.Size(86, 42)
        Me.ButtonReceive.TabIndex = 4
        Me.ButtonReceive.Text = "Receive"
        Me.ButtonReceive.UseVisualStyleBackColor = True
        '
        'TimerMain
        '
        '
        'ButtonStart
        '
        Me.ButtonStart.Enabled = False
        Me.ButtonStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonStart.Location = New System.Drawing.Point(3, 64)
        Me.ButtonStart.Name = "ButtonStart"
        Me.ButtonStart.Size = New System.Drawing.Size(86, 45)
        Me.ButtonStart.TabIndex = 5
        Me.ButtonStart.Text = "Start"
        Me.ButtonStart.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(524, 350)
        Me.Controls.Add(Me.ButtonStart)
        Me.Controls.Add(Me.ButtonReceive)
        Me.Controls.Add(Me.ButtonSend)
        Me.Controls.Add(Me.ButtonClose)
        Me.Controls.Add(Me.ButtonConnect)
        Me.Controls.Add(Me.LabelMain)
        Me.Name = "MainForm"
        Me.Text = "Test TCP WiFi Connection"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents LabelMain As Label
    Friend WithEvents ButtonConnect As Button
    Friend WithEvents ButtonClose As Button
    Friend WithEvents ButtonSend As Button
    Friend WithEvents ButtonReceive As Button
    Friend WithEvents TimerMain As Timer
    Friend WithEvents ButtonStart As Button
End Class
