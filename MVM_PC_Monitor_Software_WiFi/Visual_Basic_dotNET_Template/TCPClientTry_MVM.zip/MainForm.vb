﻿'Imports System.Net.NetworkInformation
Imports System.Net.Sockets
Imports System.Threading
Imports System.Drawing.Imaging


'Author:        Fabian Kung
'Last Modified: 6 Sep 2020
'Purpose:       A basic software to demonstrate bi-directional connection via WiFi with ESP8266
'               WiFi module using TCP.  The ESP8266 module is the host or server, while this 
'               application is the client.
'               This application uses a thread to send a command to the ESP8266 module TCP server
'               and read back a packet of bytes.  These bytes are then converted to string and 
'               displayed on the main window. RLE Compression is used.



Public Class MainForm

    'Global public datatypes declaration 
    Public Const mstrSoftwareTitle = "TCP Link for MVM - "
    Public Const mstrSoftwareVersion = "Version 0.52"
    Public Const mstrSoftwareAuthor = "Fabian Kung Wai Lee"
    Public Const mstrSoftwareDate = "25 Nov 2021"

    Dim clientSocket As System.Net.Sockets.TcpClient
    'Dim clientSocket As New System.Net.Sockets.TcpClient()
    Dim serverStream As NetworkStream
    Dim bytOutStream(32) As Byte        'Make sure there is sufficient bytes!
    Dim bytInStream(256) As Byte
    Dim nPacketCount As Integer

    Dim mintImageWidth As Integer = 160         'For QQVGA resolution.
    Dim mintImageHeight As Integer = 120
    Dim mintImageScale As Integer = 2         '2 - The displayed image will be 2X the actual size.
    '1 - This will display the image in original size (1x).


    'Graphics objects
    Private mptBmpStart As Point    'Position of bitmap (the top left hand corner).
    Private mbmpMainBMP As Bitmap   'Main bitmap display for image
    Private mrecMainBMPArea As Rectangle                        'A rectangle, specifying mbpmMainBMP properties.
    Private mbitmapdataBMPArea As BitmapData

    Dim mintCurrentBMPLine1Counter As Integer
    Dim mintDataPayload1Length As Integer
    Dim mblnResetThread As Boolean

    'Threads, here Managed Threading (.NET 4 and onwards) is used to make execution more efficient. 
    Dim t1 As New Thread(AddressOf ThreadProc1) 'Thread to buffer serial data from remote devices.
    Dim t2 As New Thread(AddressOf ThreadProc2) 'Thread to buffer serial data from remote devices.


    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles Me.Load

        Me.Text = mstrSoftwareTitle & mstrSoftwareVersion & " - " & mstrSoftwareDate

        'Initialize main picture box and graphic objects.
        mbmpMainBMP = New Bitmap(mintImageWidth + 1, mintImageHeight + 1, PixelFormat.Format24bppRgb)      'Create a bitmap for the received image.
        mptBmpStart = New Point(164, 20)        'Start position for bitmap (upper left corner).
        mrecMainBMPArea.X = 0                   'A rectangle area within the bitmap.  This will be used by the displayBitmap subroutine.
        mrecMainBMPArea.Y = 0                   'Here the area is equivalent to a row on the bitmap, thus height = 1.
        mrecMainBMPArea.Width = mbmpMainBMP.Width
        mrecMainBMPArea.Height = 1 '1 pixel

        If mintImageScale = 2 Then               'This will display the image at 2x original size.
            mbmpMainBMP.SetResolution(50, 50)    'Set resolution to 50 dots per inch.
            'If we set to 100 dots per inch, this will result in smaller image size.
        End If

    End Sub


    'NOTE: Before clicing the Connect button, make sure we connect to the ESP8266 Wifi soft Access Point
    'first!  Otherwise this function will timeout.
    Private Sub ButtonConnect_Click(sender As Object, e As EventArgs) Handles ButtonConnect.Click
        Try
            'clientSocket = New System.Net.Sockets.TcpClient() 'Create a new instance of TCP Client.
            clientSocket = New TcpClient() 'Create a new instance of TCP Client.
            If clientSocket.Connected = False Then
                clientSocket.Connect("192.168.4.1", 222)    'Connect the client to a remote TCP host in blocking fashion.
                'Based on default address from ESP8266 module.  TCP port is 222.
            End If

            'set in Arduino software.
            LabelMain.Text = "Client Connected"
            clientSocket.ReceiveTimeout = 50       'Set receive timeout value in msec.
            'clientSocket.ReceiveTimeout = 1000       'Set receive timeout value in msec. During debug it is good to have
            'longer timeout as we may need to manually trigger the sending of data.
            clientSocket.SendTimeout = 50          'Set transmit timeout value in msec.

            serverStream = clientSocket.GetStream()
            ButtonClose.Enabled = True
            ButtonSend.Enabled = True
            ButtonReceive.Enabled = True
            ButtonStart.Enabled = True
            ButtonConnect.Enabled = False

        Catch ex As Exception
            MessageBox.Show("ButtonConnect: " & ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub ButtonClose_Click(sender As Object, e As EventArgs) Handles ButtonClose.Click
        Try
            If (t1.IsAlive) Then     'Abort the secondary thread if it is still running.
                t1.Abort()
            End If
            If (t2.IsAlive) Then     'Abort the secondary thread if it is still running.
                t2.Abort()
            End If
            serverStream.Close()
            clientSocket.Close()    'Note: once closed, the TCP client will be removed from memory. So
            'we would need to create a new instance when we reconnect back.

            LabelMain.Text = "Client Closed"
            ButtonClose.Enabled = False
            ButtonSend.Enabled = False
            ButtonReceive.Enabled = False
            ButtonStart.Enabled = False
            ButtonConnect.Enabled = True
            TimerMain.Enabled = False

        Catch ex As Exception
            MessageBox.Show("ButtonClose: " & ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub ButtonSend_Click(sender As Object, e As EventArgs) Handles ButtonSend.Click

        Try
            bytOutStream(0) = 88                        ''X'
            'outStream(1) = &HA                         '\n'
            serverStream.Write(bytOutStream, 0, 1)      'Send 1 byte, 0 offset.
            serverStream.FlushAsync()                   'Clear stream.
        Catch ex As Exception
            MessageBox.Show("ButtonSend: " & ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub ButtonReceive_Click(sender As Object, e As EventArgs) Handles ButtonReceive.Click
        Dim nNumofBytesRead As Integer

        Try
            Do While serverStream.DataAvailable = True
                nNumofBytesRead = serverStream.Read(bytInStream, 0, 10)
                'The Read operation reads as much data as is available, 
                'up to the number of bytes specified by the size parameter. Here we read up to 10 bytes.
                bytInStream(nNumofBytesRead) = &HA  'Append '\n'
                MessageBox.Show("Data from Server : " + System.Text.Encoding.ASCII.GetString(bytInStream), "NOTE", MessageBoxButtons.OK)
            Loop

        Catch ex As Exception
            MessageBox.Show("ButtonReceive: " & ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub TimerMain_Tick(sender As Object, e As EventArgs) Handles TimerMain.Tick
        'Dim nNumofBytesRead As Integer

        ' Original codes with send and receive inside the TimerMain expiry routine.
        'bytOutStream(0) = 88                       ''X'
        'serverStream.Write(bytOutStream, 0, 1)     'Send 1 byte, 0 offset.

        'If serverStream.DataAvailable = True Then
        'nNumofBytesRead = serverStream.Read(bytInStream, 0, 11)
        'The Read operation reads as much data as is available, 
        'up to the number of bytes specified by the size parameter. Here we read up to 11 bytes.
        'bytInStream(nNumofBytesRead) = &HA  'Append '\n' to the last byte.
        'LabelMain.Text = System.Text.Encoding.ASCII.GetString(bytInStream)
        'End If

        Try
            'LabelMain.Text = System.Text.Encoding.ASCII.GetString(bytInStream)
            LabelMain.Text = "Packet no. " & Str(nPacketCount)
        Catch ex As Exception
            MessageBox.Show("TimerMain Tick: " & ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub ButtonStart_Click(sender As Object, e As EventArgs) Handles ButtonStart.Click

        Try
            If clientSocket.Connected = True Then
                TimerMain.Interval = 25
                'TimerMain.Enabled = True 'Only enable this during debugging, the software will run slightly faster.
                ButtonStart.Enabled = False
                nPacketCount = 0


                If t1.IsAlive = False Then          'July 2016: Once a thread is started, we cannot start it a 2nd time,
                    'else this would cause an exception.
                    t1 = New Thread(AddressOf ThreadProc1)
                    mblnResetThread = False
                    t1.Start()                      'Start the 1st thread if it is not running.
                End If

                'If t2.IsAlive = False Then          'July 2016: Once a thread is started, we cannot start it a 2nd time,
                'else this would cause an exception.
                't2 = New Thread(AddressOf ThreadProc2)
                't2.Start()                      'Start the 1st thread if it is not running.
                'End If

                'Initiate by sending the command to MVM.
                bytOutStream(0) = 88                    ''X'
                serverStream.Write(bytOutStream, 0, 1)  'Send 1 byte, 0 offset.
                serverStream.FlushAsync()               'Clear stream.
            Else
                MessageBox.Show("No connection, please connect to a server first", "ERROR", MessageBoxButtons.OK)
            End If
        Catch ex As Exception
            MessageBox.Show("ButtonStart: " & ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try

    End Sub

    Public Sub ThreadProc1()
        Static Dim nState As Integer = 0
        Dim nNumofBytesRead As Integer
        Static Dim nTimeoutCount As Integer = 0


        Try
            While 1 'If we don't put the infinite while (1), the thread will exit after executing once.
                If clientSocket.Connected = True Then
                    Select Case nState
                        Case 0
                            'Note: 9 Sep 2020.  Actually measurement of the timing using MSOX oscilloscope indicates that there is
                            'not much difference in the update speed of each line of pixel, whether the DisplayBitmap() is placed 
                            'here or inside the If-Else-End IF loop.
                            'Note:
                            'nNumofBytesRead = serverStream.Read(bytInStream, 0, 11)
                            'The Read operation reads as much data as is available, 
                            'up to the number of bytes specified by the size parameter. Here we read up to 11 bytes.
                            If serverStream.DataAvailable = True Then
                                nNumofBytesRead = serverStream.Read(bytInStream, 0, 3)  'Read 1st 3 bytes (the header) with 0 bytes offset.
                                'Note: We need to call the display bitmap routine first, as the receive buffer is already
                                'filled with pixel data from the previous read.  After putting this pixel data onto the display
                                'then only read the input stream for new pixel data.  Else we would corrupt the line counter 
                                'and payload length variables.
                                DisplayBitmap()                                 'Use display bitmap routine with line compression.
                                'DisplayBitmapNoCompression()                   'Use display bitmap routine without line compression.

                                mintCurrentBMPLine1Counter = bytInStream(1)     'Get current image line number.
                                mintDataPayload1Length = bytInStream(2)         'Get the length of the pixel data payload.
                                nState = 1
                            Else
                                nState = 0
                            End If

                        Case 1
                            If serverStream.DataAvailable = True Then
                                'Read into input buffer, with 3 bytes offset. The 1st 3 bytes are reserved for the header.
                                nNumofBytesRead = serverStream.Read(bytInStream, 3, mintDataPayload1Length)
                                nPacketCount = nPacketCount + 1             'Update packet counter.
                                serverStream.FlushAsync()                   'Clear stream.
                                bytOutStream(0) = 88                        ''X', ask MVM to resend next line of pixel data.
                                serverStream.Write(bytOutStream, 0, 1)      'Send 1 byte, 0 offset.
                                nState = 0
                            Else
                                nState = 1
                            End If

                        Case Else
                            nState = 0
                            'Thread.Sleep(0)
                    End Select
                End If 'If clientSocket.Connected = True
            End While

            'Catch ex As Exception
        Catch ex As ThreadAbortException
            'MessageBox.Show("Thread1: " & CStr(nState) & ": " & ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try

    End Sub

    'Note: 9 Sep 2020, experiment shows that using a 2nd thread to display the bitmap does not speed up the frame update
    'rate significantly, so I am not going to use the 2nd thread for now.
    Public Sub ThreadProc2()
        Static Dim nState As Integer = 0

        Try
            While 1
                If clientSocket.Connected = True Then
                    DisplayBitmap()
                End If 'If clientSocket.Connected = True
            End While

            'Catch ex As Exception
        Catch ex As ThreadAbortException
            'MessageBox.Show("Thread2: " & CStr(nState) & ": " & ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try

    End Sub

    'Last updated:  31 Aug 2020
    'Author:        Fabian Kung
    'Subroutine to update the bitmap image one line at a time.  Also superimpose markers or ROI.
    'No compression is assumed.
    '
    '--- 1. Format for 1 line of pixel data ---
    'The data format:
    'Byte0: 0xFF (Indicate start-of-line)
    'Byte1: Line number, 0-253, indicate the line number In the bitmap image.
    '       if Byte1 = 254, it indicate the following bytes are secondary data.  
    'Byte2: The length Of the data payload, excluding Byte0-2.
    'Byte3-ByteN: Data payload.
    'The data payload only accepts 8 bits value, from bit0-bit7.  

    'Example
    'Consider the following byte stream:
    '[0xFF][3][7][90][80][70][0x83][60][0x82][120]
    'Byte2 = 7 indicates that there are 7 data bytes in this data packet.
    'Byte3 = 90 represent the 1st pixel data in line 3.  This value can represent the 
    '         luminance value of other user define data.
    'Byte4 = 80 another pixel data.
    'Byte5 = 70 another pixel data.
    'Byte6 = 0x83 another pixel data.
    ' ....
    'Byte9 = 120, another pixel.
    '

    Private Sub DisplayBitmapNoCompression()

        Static Dim nR8 As Integer
        Dim nData As Integer
        Dim nX As Integer
        Dim nY As Integer
        Dim nIndex As Integer
        Dim nXCoor As Integer
        Dim nYCoor As Integer
        Dim graphicObject As Graphics
        Dim ptrBitmap As IntPtr
        Dim nPixelSize As Integer
        Dim nPixelIndex As Integer
        Dim bytes As Integer
        Static Dim nBitmapLocked As Integer = 0
        Static Dim nColorR As Integer       'RGB components for pixel color.
        Static Dim nColorG As Integer
        Static Dim nColorB As Integer

        Try
            nY = mintCurrentBMPLine1Counter + 1     'Get line number, add 1 since the value starts from 0.  The bitmap coordinate index starts from 1

            If (nY <= mintImageHeight) Then         'Make sure line no. is less than image height in pixels.

                'window coordinate starts from 1.
                nYCoor = nY   'Form Y coordinate of pixel in bitmap.
                nX = 0

                If nBitmapLocked = 0 Then           'Check if the bitmap area is already locked.  If not then proceed.  An exception will be raised
                    'if we did not release previously locked region.
                    nBitmapLocked = 1
                    mrecMainBMPArea.Y = nYCoor      'Note, the width, and x starting position is already declared when the application loaded.  We only need to
                    'set the y starting position.
                    mbitmapdataBMPArea = mbmpMainBMP.LockBits(mrecMainBMPArea, ImageLockMode.WriteOnly, mbmpMainBMP.PixelFormat)  'Assign a temporary buffer corresponds to the main bitmap.
                    'This is a 1D array to store 2D bitmap data, with each row of the bitmap being join to each other.  Thus in order to gain access to a pixel, we need to know:
                    ' a) It's (x,y) coordinate.
                    ' b) the Stride.  The Stride = (no. of pixels per row) x (no. of bytes per pixel).
                    ' Thus if we use Format24bpprgb format for the pixel, there are 3 bytes per pixel.
                    ' For a bitmap image of width = 160 pixels, the Stride = 480 bytes.
                End If
                nPixelSize = 3                          '3 bytes per pixel
                ptrBitmap = mbitmapdataBMPArea.Scan0    'Get the start address of bitmap memory.
                'bytes = Math.Abs(mbitmapdataBMPArea.Stride) * mbmpMainBMP.Height
                bytes = Math.Abs(mbitmapdataBMPArea.Stride)
                Dim rgbValues(bytes - 1) As Byte        ' Declare an array to hold the bytes of the bitmap.
                Runtime.InteropServices.Marshal.Copy(ptrBitmap, rgbValues, 0, bytes)  ' Copy the RGB values into the array.

                'Retrive gray scale data and plot on bitmap.  
                For nIndex = 0 To mintDataPayload1Length - 1
                    nData = bytInStream(nIndex + 3)    'Get pixel luminance data or repetition number from the buffer, 3 bytes offset.  The 
                    '1st 3 bytes are for the header.

                    nX = nX + 1
                    If (nX > mintImageWidth) Then 'Make sure X position is smaller than image width.
                        Return
                    End If

                    nXCoor = nX                     'Form X coordinate of pixel in bitmap.
                    nPixelIndex = nXCoor * nPixelSize

                    nR8 = nData                     'Read pixel data
                    If nR8 > 255 Then               'Limit the maximum value.
                        nR8 = 255
                    End If

                    nColorR = nR8 * 2   'Since the value is limited to 127, we multiply by 2 to increase the effective brightness.
                    nColorG = nColorR   'Convert to grayscale.
                    nColorB = nColorR

                    'Form a pixel 
                    rgbValues(nPixelIndex) = nColorB           'Blue component.
                    rgbValues(nPixelIndex + 1) = nColorG       'Green component.
                    rgbValues(nPixelIndex + 2) = nColorR       'Red component.
                Next nIndex

                'If nBitmapLocked = 1 Then  'If there is bitmap region locked, release it.
                Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptrBitmap, bytes)  ' Copy the RGB values back to the bitmap
                mbmpMainBMP.UnlockBits(mbitmapdataBMPArea)  'Copy the buffer data back to the bitmap.
                nBitmapLocked = 0
                'End If

                ' --- Display 2 lines at a time ---
                'If (nYCoor Mod 2) = 0 Then  'Only update the bitmap display every other lines.
                'graphicObject = Me.CreateGraphics
                'Dim srcRec = New Rectangle(1, nYCoor - 2, mbmpMainBMP.Width, 2)
                'graphicObject.DrawImage(mbmpMainBMP, mptBmpStart)                  'Display whole bitmap 
                'graphicObject.DrawImage(mbmpMainBMP, mptBmpStart.X, mptBmpStart.Y + 2 * nYCoor, srcRec, GraphicsUnit.Pixel) 'Display only 2 rows
                'graphicObject.Dispose()
                'Release all resources used by graphic object.  Note: 30 April 2018, if this is not done,
                'I observed that the memory used by this application will slowly increase over time while
                'debugging the software in Visual Studio.  
                'End If

                ' --- Display 4 lines at a time ---
                If (nYCoor Mod 4) = 0 Then  'Only update the bitmap display every 4 lines.
                    graphicObject = Me.CreateGraphics
                    Dim srcRec = New Rectangle(1, nYCoor - 2, mbmpMainBMP.Width, 4)
                    'graphicObject.DrawImage(mbmpMainBMP, mptBmpStart)                  'Display whole bitmap 
                    graphicObject.DrawImage(mbmpMainBMP, mptBmpStart.X, mptBmpStart.Y + 2 * nYCoor, srcRec, GraphicsUnit.Pixel) 'Display only 4 rows
                    graphicObject.Dispose()
                    'Release all resources used by graphic object.  Note: 30 April 2018, if this is not done,
                    'I observed that the memory used by this application will slowly increase over time while
                    'debugging the software in Visual Studio.  
                End If

            End If 'End of If (nY <= mintImageHeight) Then

            mintCurrentBMPLine1Counter = 100000         'Invalidate current line so that this function will not run anymore until a new line data has been buffered.

        Catch ex As ThreadAbortException

        Catch ex As Exception
            MessageBox.Show(ex.Message, "DisplayBitmapNoCompression Error at line " & CStr(nY), MessageBoxButtons.OK)
        End Try
    End Sub

    'Last updated:  21 Nov 2019
    'Author:        Fabian Kung
    'Subroutine to update the bitmap image one line at a time.  Also superimpose markers or ROI.
    '
    '--- 1. Format for 1 line of pixel data ---
    'The image data Is send to the remote display line-by-line, using a simple RLE (Run-Length 
    'Encoding) compression format. The data format:
    'Byte0: 0xFF (Indicate start-of-line)
    'Byte1: Line number, 0-253, indicate the line number In the bitmap image.
    '       if Byte1 = 254, it indicate the following bytes are secondary data.  
    'Byte2: The length Of the data payload, excluding Byte0-2.
    'Byte3-ByteN: Data payload.
    'The data payload only accepts 7 bits value, from bit0-bit6.  Bit7 Is used to indicate
    'repetition in the RLE algorithm, the example below elaborate further.

    'Example
    'Consider the following byte stream:
    '[0xFF][3][7][90][80][70][0x83][60][0x82][120]
    'Byte2 = 7 indicates that there are 6 data bytes in this data packet.
    'Byte3 = 90 represent the 1st pixel data in line 3.  This value can represent the 
    '         luminance value of other user define data.
    'Byte4 = 80 another pixel data.
    'Byte5 = 70 another pixel data.
    'Byte6 = 0x83 = 0b10000000 + 3.  This indicates the last byte, e.g. Byte5=70 Is to
    '         be repeated 3 times, thus there are a total of 4 pixels with value of 70
    '         after pixel with value of 80. 
    'Byte7 = 60 another pixel data.
    'Byte8 = 0x82 = 0b10000000 + 2.  The pixel with value of 60 Is to be repeated 2 times.
    'Byte9 = 120, another pixel.
    '
    'The complete line of pixels Is as follows:
    'Line3 [90][80][70][70][70][70][60][60][60][120]
    '
    'This subroutine must thus be able to decode the above format and setup the bitmap pixels
    'accordingly
    'The maximumum no. of repetition: Currently the maximum no. Of repetition Is 63.  If 
    'there are 64 consequtive pixels with values of 70, we would write [70][0x80 + 0x3F]
    'Or [70][0x10111111].  The '0' at bit 6 is to prevention a repetition code of 0xFF, which
    'can be confused with start-of-line value.
    '

    Private Sub DisplayBitmap()

        Static Dim nR8 As Integer

        Dim nData As Integer
        Dim nRepetition As Integer
        Dim nX As Integer
        Dim nY As Integer
        Dim nIndex As Integer
        Dim nIndex2 As Integer
        Dim nXCoor As Integer
        Dim nYCoor As Integer
        Dim graphicObject As Graphics
        Dim ptrBitmap As IntPtr
        Dim nPixelSize As Integer
        Dim nPixelIndex As Integer
        Dim bytes As Integer
        Static Dim nBitmapLocked As Integer = 0
        Static Dim nColorR As Integer       'RGB components for pixel color.
        Static Dim nColorG As Integer
        Static Dim nColorB As Integer


        Try

            nY = mintCurrentBMPLine1Counter + 1  'Get line number, add 1 since the value starts from 0.  The bitmap coordinate index starts from 1.

            If (nY <= mintImageHeight) Then         'Make sure line no. is less than image height in pixels.

                'window coordinate starts from 1.
                nYCoor = nY   'Form Y coordinate of pixel in bitmap.
                nX = 0        'Initialize x coordinate. 

                If nBitmapLocked = 0 Then           'Check if the bitmap area is already locked.  If not then proceed.  An exception will be raised
                    'if we did not release previously locked region.
                    nBitmapLocked = 1
                    mrecMainBMPArea.Y = nYCoor      'Note, the width, and x starting position is already declared when the application loaded.  We only need to
                    'set the y starting position.
                    mbitmapdataBMPArea = mbmpMainBMP.LockBits(mrecMainBMPArea, ImageLockMode.WriteOnly, mbmpMainBMP.PixelFormat)  'Assign a temporary buffer corresponds to the main bitmap.
                    'This is a 1D array to store 2D bitmap data, with each row of the bitmap being join to each other.  Thus in order to gain access to a pixel, we need to know:
                    ' a) It's (x,y) coordinate.
                    ' b) the Stride.  The Stride = (no. of pixels per row) x (no. of bytes per pixel).
                    ' Thus if we use Format24bpprgb format for the pixel, there are 3 bytes per pixel.
                    ' For a bitmap image of width = 160 pixels, the Stride = 480 bytes.
                End If
                nPixelSize = 3                          '3 bytes per pixel
                ptrBitmap = mbitmapdataBMPArea.Scan0    'Get the start address of bitmap memory.
                bytes = Math.Abs(mbitmapdataBMPArea.Stride) 'No. of bytes for 1 line of bitmap data.
                Dim rgbValues(bytes - 1) As Byte        ' Declare an array to hold the bytes of the bitmap.
                Runtime.InteropServices.Marshal.Copy(ptrBitmap, rgbValues, 0, bytes)  ' Copy the RGB values into the array.

                'Retrive gray scale data and plot on bitmap.  
                For nIndex = 0 To mintDataPayload1Length - 1
                    nData = bytInStream(nIndex + 3)     'Get pixel luminance data or repetition number from the buffer, 3 bytes offset.  The 
                    '1st 3 bytes are for the header.

                    If (nData > 128) Then               'Check if bit7 is set, this indicate repetition number.
                        nRepetition = nData And &H3F    'Mask out bit7 and bit6.
                        If (nRepetition > 0) Then       'Make sure repetition is not 0.
                            For nIndex2 = 0 To nRepetition - 1

                                nX = nX + 1
                                If (nX > mintImageWidth) Then 'Make sure X position is smaller than image width.
                                    Return
                                End If

                                nXCoor = nX             'Form X coordinate of pixel in bitmap.
                                nPixelIndex = nXCoor * nPixelSize 'Form pixel x coordinate.

                                'Form a pixel. 
                                'Update image.  Note: the RGB components values are already set from the initial pixel
                                'in the similar color group.
                                rgbValues(nPixelIndex) = nColorB           'Blue component.
                                rgbValues(nPixelIndex + 1) = nColorG       'Green component.
                                rgbValues(nPixelIndex + 2) = nColorR       'Red component.

                            Next nIndex2 'For nIndex2 = 0 To nRepetition - 1
                        End If 'If (nRepetition > 0)
                    Else            'Not repetition, new pixel data.
                        nX = nX + 1
                        If (nX > mintImageWidth) Then 'Make sure X position is smaller than image width.
                            Return
                        End If

                        nXCoor = nX                     'Form X coordinate of pixel in bitmap.
                        nPixelIndex = nXCoor * nPixelSize

                        nR8 = nData                     'Read pixel data
                        If nR8 > 127 Then               'Limit the maximum value.
                            nR8 = 127
                        End If

                        nColorR = 2 * nR8   'Since the value is limited to 127, we multiply by 2 to increase the effective brightness.
                        nColorG = nColorR   'Convert to grayscale.
                        nColorB = nColorR

                        'Form a pixel 
                        rgbValues(nPixelIndex) = nColorB           'Blue component.
                        rgbValues(nPixelIndex + 1) = nColorG       'Green component.
                        rgbValues(nPixelIndex + 2) = nColorR       'Red component.

                    End If 'If (nData > 128)
                Next nIndex

                'If nBitmapLocked = 1 Then  'If there is bitmap region locked, release it.
                Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptrBitmap, bytes)  ' Copy the RGB values back to the bitmap
                mbmpMainBMP.UnlockBits(mbitmapdataBMPArea)  'Copy the buffer data back to the bitmap.
                nBitmapLocked = 0
                'End If

                'If (nYCoor Mod 2) = 0 Then  'Only update the bitmap display every other lines.
                'graphicObject = Me.CreateGraphics
                'Dim srcRec = New Rectangle(1, nYCoor - 2, mbmpMainBMP.Width, 2)
                'graphicObject.DrawImage(mbmpMainBMP, mptBmpStart)                  'Display whole bitmap 
                'graphicObject.DrawImage(mbmpMainBMP, mptBmpStart.X, mptBmpStart.Y + 2 * nYCoor, srcRec, GraphicsUnit.Pixel) 'Display only 2 rows

                'mgraphicObject.DrawImage(mbmpMainBMP, mptBmpStart)                  'Display only 2 rows. 
                'mgraphicObject.DrawImage(mbmpMainBMP, mptBmpStart.X, mptBmpStart.Y + 2 * nYCoor, srcRec, GraphicsUnit.Pixel) 'Display only 2 rows
                'graphicObject.DrawImage(mbmpMainBMP, mptBmpStart.X, mptBmpStart.Y + 2 * nYCoor, srcRec, GraphicsUnit.Pixel) 'Display only 2 rows
                'graphicObject.Dispose()
                'Release all resources used by graphic object.  Note: 11 July 2019, if this is not done,
                'I observed that the memory used by this application will slowly increase over time while
                'debugging the software in Visual Studio.  Alternative is to use global graphic resources, 
                'so that we do not have to create new graphic resources every time.
                'End If

                If (nYCoor Mod 10) = 0 Then  'Only update the bitmap display every 10 lines.
                    graphicObject = Me.CreateGraphics
                    Dim srcRec = New Rectangle(1, nYCoor - 10, mbmpMainBMP.Width, 10)     'Create a new rectangle, width = main bitmap width, height = 10.
                    'x coordinate = 1, y coordinate = offset of current row by 10.
                    'graphicObject.DrawImage(mbmpMainBMP, mptBmpStart)                  'Display whole bitmap 
                    'graphicObject.DrawImage(mbmpMainBMP, mptBmpStart.X, mptBmpStart.Y + 2 * nYCoor, srcRec, GraphicsUnit.Pixel) 'Display only 2 rows

                    'mgraphicObject.DrawImage(mbmpMainBMP, mptBmpStart)                  'Display only 2 rows. 
                    'mgraphicObject.DrawImage(mbmpMainBMP, mptBmpStart.X, mptBmpStart.Y + 2 * nYCoor, srcRec, GraphicsUnit.Pixel) 'Display current rectangle in bitmap.
                    graphicObject.DrawImage(mbmpMainBMP, mptBmpStart.X, mptBmpStart.Y + 2 * nYCoor, srcRec, GraphicsUnit.Pixel) 'Display current rectangle in bitmap.
                    graphicObject.Dispose()
                    'Release all resources used by graphic object.  Note: 11 July 2019, if this is not done,
                    'I observed that the memory used by this application will slowly increase over time while
                    'debugging the software in Visual Studio.  Alternative is to use global graphic resources, 
                    'so that we do not have to create new graphic resources every time.
                End If
            End If 'End of If (nY <= mintImageHeight) Then

            mintCurrentBMPLine1Counter = 100000         'Invalidate current line so that this function will not run anymore until a new line data has been buffered.

        Catch ex As ThreadAbortException

        Catch ex As Exception
            MessageBox.Show(ex.Message, "DisplayBitmap Error at line " & CStr(nY), MessageBoxButtons.OK)
        End Try
    End Sub

End Class
